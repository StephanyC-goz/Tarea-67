# Dirección Nacional SENATI — maqueta 3D exterior (versión 1)

## Alcance y precisión

Proyecto académico en HTML, CSS y Three.js. Incluye dos fotografías aportadas por el usuario, fachada conceptual de cinco niveles visibles, costillas inclinadas, torre lateral, ventanales, marquesina, letrero SENATI, veredas y vegetación representativa. Las proporciones, alturas, profundidades, materiales de superficies no visibles, laterales y elementos del entorno son **aproximaciones ilustrativas**. Este modelo **no es un plano estructural**, ni está destinado a construir ni evaluar la seguridad del edificio. No incorpora distribuciones interiores supuestas.

## Instalar en Laragon (opción recomendada)

1. Descomprime la carpeta `Piramide_SENATI_Exterior_3D` dentro de `C:\laragon\www`.
2. Ejecuta **`INSTALAR.bat`** (con internet la primera vez). Copia o descarga Three.js y lo deja en `js/vendor/three.module.js`.
3. Inicia **Apache** desde Laragon. No requiere MySQL.
4. Abre `http://localhost:8080/Piramide_SENATI_Exterior_3D/` si tu Apache usa puerto 8080, o `http://localhost/Piramide_SENATI_Exterior_3D/` si utiliza el 80.
5. En caso de HTTP 404 para `three.module.js`, ejecuta **`REPARAR_THREE.bat`**, luego actualiza con Ctrl+F5. Verifica que `http://localhost:8080/Piramide_SENATI_Exterior_3D/js/vendor/three.module.js` entregue código JS.

La biblioteca Three.js se **carga desde el disco local**, sin CDN durante la navegación. Si no tienes Node.js, el reparador PowerShell puede descargar la biblioteca sin usar npm. **La biblioteca no se incluye físicamente en el ZIP**, porque no estuvo disponible para descarga en el entorno de construcción.

## Instalar con Node.js / Visual Studio Code

```bash
cd Piramide_SENATI_Exterior_3D
npm install
npm start
```

Visita `http://localhost:3000`. `npm install` copia automáticamente el módulo Three.js a `js/vendor/three.module.js`. Si npm da problemas, ejecuta el reparador de Windows primero.

## Controles

- Ratón: clic sostenido y mover para orbitar el edificio.
- Rueda: zoom.
- Vistas: general, frente, lateral y superior.
- `Recorrer en primera persona`: clic y arrastrar para mirar, `WASD` o flechas para caminar, `Shift` para desplazamiento rápido, `Esc` para salir.
- Panel de capas: cartel, entorno, soportes y cubiertas.
- Materiales: colores ajustables para concreto, azul y cristales; se guardan en navegador.

## Archivos

- `index.html`: interfaz.
- `css/estilos.css`: estilos.
- `js/main.js`: geometría y navegación Three.js.
- `js/iniciar.js`: diagnóstico de carga de Three.js.
- `scripts/preparar-three.cjs`: copiar Three.js desde npm.
- `scripts/reparar-three.ps1`: reparador alternativo.
- `referencias/fachada_frontal.jpg`, `referencias/fachada_perspectiva.jpg`: fotos aportadas por el usuario.

## Para avanzar a una reconstrucción fiel

Faltan: planta arquitectónica por piso, elevaciones lateral/trasera, medidas reales y fotografías del acceso y laterales. Para un modelo *estructural* se necesitan planos de columnas, vigas, losas, cimentaciones u otros elementos relevantes. Sin ellos, solo es correcto realizar una maqueta arquitectónica aproximada.
