(async()=>{
  const box=document.querySelector('#error');
  const fail=(msg)=>{box.classList.remove('hidden');box.textContent=msg;};
  const path='js/vendor/three.module.js';
  try{
    const response=await fetch(path,{cache:'no-store'});
    if(!response.ok)throw new Error('Falta '+path+' (HTTP '+response.status+'). Ejecuta INSTALAR.bat; es necesario descargar Three.js una sola vez.');
    if(!(response.headers.get('content-type')||'').includes('javascript'))throw new Error('Apache entrega Three.js con un tipo de archivo incorrecto.');
    await import('./main.js');
  }catch(e){console.error(e);fail('No se pudo abrir el modelo 3D. '+e.message+'\n\nInstala la biblioteca local con INSTALAR.bat y abre la aplicación desde INICIAR.bat o Apache de Laragon. No abras el archivo HTML haciendo doble clic.');}
})();
