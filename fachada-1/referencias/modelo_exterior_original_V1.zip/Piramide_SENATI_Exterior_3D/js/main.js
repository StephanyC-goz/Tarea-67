import * as THREE from './vendor/three.module.js';

const $ = s => document.querySelector(s);
const viewport=$('#viewport');
const defaults={concrete:'#958779',blue:'#126cce',glass:'#567b90'};
const readStorage=(k,d)=>{try{return localStorage.getItem(k)||d}catch{return d}};

const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure=1.23;
renderer.shadowMap.enabled=true;
renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.8));
viewport.appendChild(renderer.domElement);

const scene=new THREE.Scene();
scene.background=new THREE.Color(0xddeef5);
scene.fog=new THREE.Fog(0xddeef5,95,200);
const group=new THREE.Group();scene.add(group);
const environment=new THREE.Group();scene.add(environment);
const signage=new THREE.Group();group.add(signage);
const supportGroup=new THREE.Group();group.add(supportGroup);
const roofGroup=new THREE.Group();group.add(roofGroup);
const pickables=[];
const M={
 concrete:new THREE.MeshStandardMaterial({color:readStorage('concreteColor',defaults.concrete),roughness:.90}),
 concreteLite:new THREE.MeshStandardMaterial({color:0xa99e8f,roughness:.91}),
 concreteDark:new THREE.MeshStandardMaterial({color:0x695e58,roughness:.89}),
 white:new THREE.MeshStandardMaterial({color:0xdbe2e3,roughness:.78}),
 bright:new THREE.MeshStandardMaterial({color:0xf5f6f2,roughness:.82}),
 blue:new THREE.MeshStandardMaterial({color:readStorage('blueColor',defaults.blue),metalness:.05,roughness:.38}),
 deepBlue:new THREE.MeshStandardMaterial({color:0x0a458b,roughness:.5}),
 glass:new THREE.MeshPhysicalMaterial({color:readStorage('glassColor',defaults.glass),roughness:.14,metalness:.18,transparent:true,opacity:.86,side:THREE.DoubleSide}),
 dark:new THREE.MeshStandardMaterial({color:0x23313a,metalness:.18,roughness:.57}),
 darkGlass:new THREE.MeshPhysicalMaterial({color:0x264859,roughness:.18,metalness:.17,transparent:true,opacity:.80}),
 black:new THREE.MeshStandardMaterial({color:0x141f2b,roughness:.65}),
 ground:new THREE.MeshStandardMaterial({color:0xc7cfca,roughness:.98}),
 lawn:new THREE.MeshStandardMaterial({color:0x477d50,roughness:.96}),
 yellow:new THREE.MeshStandardMaterial({color:0xf6b81a,roughness:.72}),
 leaf:new THREE.MeshStandardMaterial({color:0x407b52,roughness:.96}),
 trunk:new THREE.MeshStandardMaterial({color:0x806550,roughness:.96})
};
function box(parent,w,h,d,x,y,z,mat,part,shadow=true){
 const ob=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);
 ob.position.set(x,y,z);ob.castShadow=shadow;ob.receiveShadow=true;ob.userData.part=part||'';
 parent.add(ob);if(part)pickables.push(ob);return ob;
}
function cylinder(parent,r,h,x,y,z,mat,seg=16){
 const ob=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,seg),mat);
 ob.position.set(x,y,z);ob.castShadow=true;ob.receiveShadow=true;parent.add(ob);return ob;
}
function beamBetween(parent,a,b,width,depth,mat,part){
 const av=new THREE.Vector3(...a),bv=new THREE.Vector3(...b),delta=bv.clone().sub(av);
 const beam=new THREE.Mesh(new THREE.BoxGeometry(width,delta.length(),depth),mat);
 beam.position.copy(av.add(bv).multiplyScalar(.5));
 beam.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize());
 beam.castShadow=true;beam.receiveShadow=true;beam.userData.part=part||'';
 parent.add(beam);if(part)pickables.push(beam);return beam;
}
function labelTexture(text,w=1400,h=220){
 const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
 const c=canvas.getContext('2d');c.fillStyle='#126cce';c.fillRect(0,0,w,h);
 c.fillStyle='#fff';c.font=`900 ${Math.round(h*.73)}px Arial, sans-serif`;
 c.textBaseline='middle';c.textAlign='center';c.fillText(text,w/2,h*.52);
 const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());return tex;
}

// EXTERIOR CONCEPTUAL: dimensiones ilustrativas, no derivadas de levantamiento topográfico.
function buildBuilding(){
 // Plataforma y bloque general
 box(group,32,.65,20,0,.12,-.7,M.ground,'Plataforma del conjunto');
 box(group,23.8,19.8,11.6,1.90,10.12,-1.05,M.concrete,'Volumen principal');
 // Piso cero y recepción detrás del ventanal
 box(group,23.6,2.1,.26,1.9,1.65,4.87,M.concreteDark,'Base de fachada');
 // Ventanales en cinco niveles, con bandas horizontales blancas
 for(let floor=0;floor<5;floor++){
   const rowY=4.25+floor*3.08;
   // Antepecho horizontal blanco y alféizar
   box(group,23.2,.55,.34,1.9,rowY-.91,5.01,M.white,'Franja de fachada');
   box(group,23.2,.18,.36,1.9,rowY+.85,5.02,M.bright,'Franja de fachada',false);
   for(let bay=0;bay<14;bay++){
     const left=-9.45+bay*1.62;
     box(group,1.49,1.54,.10,left,rowY,5.06,M.glass,'Ventanales frontales',false);
     box(group,.045,1.57,.15,left+.79,rowY,5.17,M.dark,'Marcos metálicos',false);
     box(group,1.51,.038,.14,left,rowY+.23,5.17,M.dark,'Marcos metálicos',false);
   }
   box(group,23.15,.22,.36,1.9,rowY-1.21,5.08,M.white,'Franjas blancas');
 }
 // Banda superior de coronación
 box(group,23.8,.58,.55,1.9,19.9,5.07,M.concreteLite,'Remate superior');
 // Soportes inclinados estructurales VISIBLES en fotografías (recreación superficial)
 for(const x of [-8.75,-1.8,4.45,10.8]){
   beamBetween(supportGroup,[x-.56,1.9,6.42],[x+.35,19.5,5.34],.59,.70,M.concreteLite,'Soporte inclinado visible');
   box(supportGroup,.8,.32,1.2,x-.45,1.85,6.3,M.concrete,'Base de soporte');
 }
 // Panel lateral izquierda / torre de escalera (espacios interiores no reconstruidos)
 box(group,5.2,20.65,12,-12.48,10.65,-1.1,M.concrete,'Volumen lateral de escalera');
 // Fachada frontal de la torre sobresale y dibuja ligera inclinación
 beamBetween(group,[-10.35,2.9,6.65],[-11.75,20.1,4.85],3.15,1.05,M.concrete,'Costilla de torre lateral');
 for(const y of [4.3,8.2,12.1,16.1]){
   box(group,1.17,.47,.15,-12.46,y,5.05,M.darkGlass,'Ventanas pequeñas de torre',false);
 }
 // Huecos oscuros y paños azules del extremo izquierdo
 box(group,2.17,6.2,.19,-15.11,7.6,4.7,M.deepBlue,'Receso azul lateral');
 box(group,5.3,1.95,3.15,-14.64,18.7,5.7,M.bright,'Voladizo blanco superior');
 box(group,5.3,.32,3.45,-14.64,17.65,5.65,M.concreteDark,'Sombra del voladizo');
 // Elemento lateral derecho azul
 box(group,1.27,19.95,11.75,14.23,10.2,-1.0,M.deepBlue,'Costado azul');
 box(group,1.1,8.2,11.75,14.28,7.1,-1,M.blue,'Panel azul lateral');
 // Pequeñas líneas de vidrio de fachada lateral
 for(let i=0;i<5;i++){
   box(group,.08,1.00,7,14.93,5.1+i*2.68,-1.0,M.darkGlass,'Ventanales laterales',false);
 }
 // Envolvente visible del techo y su estructura sencilla, sin suponer interiores
 box(roofGroup,26.3,.55,13.0,0.3,20.42,-.92,M.concreteLite,'Azotea');
 for(const x of [-8.7,-3.2,2.5,8.0]){
  box(roofGroup,.28,1.25,.28,x,21.27,2.85,M.dark,'Soporte de cartel');
 }
 // Gran cartel SENATI en la fachada exterior, a modo de maqueta
 box(signage,23.3,3.55,.30,2.15,23.48,5.45,M.blue,'Cartel SENATI');
 const signMat=new THREE.MeshBasicMaterial({map:labelTexture('SENATI',1600,300),side:THREE.DoubleSide});
 const signMesh=new THREE.Mesh(new THREE.PlaneGeometry(22.9,3.22),signMat);
 signMesh.position.set(2.15,23.49,5.65);signMesh.userData.part='Logotipo SENATI (tipografía referencial)';
 signage.add(signMesh);pickables.push(signMesh);
 // Paneles secundarios en techo (indicativos)
 box(roofGroup,9.8,1.2,2.4,-11.2,21.35,-4.35,M.dark,'Panel posterior visible');
}

function tree(x,z,r=1){
 cylinder(environment,.16,2.8,x,1.6,z,M.trunk);
 const geo=new THREE.IcosahedronGeometry(r,1);
 const top=new THREE.Mesh(geo,M.leaf);top.scale.set(1.1,1.45,1.05);top.position.set(x,3.9,z);top.castShadow=true;environment.add(top);
 for(let i=0;i<4;i++){
   const top2=new THREE.Mesh(geo,M.leaf);top2.scale.set(.68,.85,.68);
   top2.position.set(x+Math.cos(i*1.57)*r*.56,3.4,z+Math.sin(i*1.57)*r*.56);
   top2.castShadow=true;environment.add(top2);
 }
}
function person(x,z,shirt=M.blue){
 const g=new THREE.Group();g.position.set(x,0,z);environment.add(g);
 cylinder(g,.14,.82,-.13,.46,0,M.dark,12);
 cylinder(g,.14,.82,.13,.46,0,M.dark,12);
 box(g,.51,.84,.29,0,1.28,0,shirt);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.22,16,12),new THREE.MeshStandardMaterial({color:0xb89479,roughness:.94}));
 head.position.set(0,1.92,0);head.castShadow=true;g.add(head);
}
function buildGround(){
 const plaza=new THREE.Mesh(new THREE.PlaneGeometry(140,140),M.ground);
 plaza.rotation.x=-Math.PI/2;plaza.position.y=-.26;plaza.receiveShadow=true;environment.add(plaza);
 // Aceras y plaza de ingreso
 box(environment,34,.08,17,0,-.03,15.5,M.white);
 box(environment,36,.15,.45,0,.02,23.45,M.yellow,'Borde amarillo de pista');
 const grass=new THREE.Mesh(new THREE.PlaneGeometry(45,17),M.lawn);grass.rotation.x=-Math.PI/2;grass.position.set(0,-.01,33);grass.receiveShadow=true;environment.add(grass);
 // Marquesina horizontal con techo azul frente al acceso
 box(environment,20,.35,6.0,6.0,4.10,10.9,M.blue,'Cubierta de acceso');
 box(environment,20,.28,6.15,6.0,4.28,10.9,M.bright,'Remate de marquesina');
 for(const x of [-3.2,2.9,9.0,14.6]){
  box(environment,.18,4.1,.19,x,2.0,13.65,M.dark,'Soportes de marquesina');
 }
 // Puertas del vestíbulo referencial
 for(let i=0;i<6;i++){
   box(environment,2.5,3.45,.14,-2.4+i*3.15,1.75,8.01,M.darkGlass,'Cristal de acceso',false);
   box(environment,.10,3.6,.17,-1+i*3.15,1.78,8.1,M.dark,'Carpintería de acceso',false);
 }
 // Cerca perimetral y postes, estilo de reja deportiva cercana (indicativa)
 for(const x of [-18,18]){
  box(environment,.10,3.0,.10,x,1.5,18.0,M.black);
 }
 for(let i=-17;i<=17;i+=2.4){box(environment,.038,2.2,.038,i,1.24,18.0,M.black);}
 box(environment,35.7,.045,.045,0,.62,18.0,M.black);
 box(environment,35.7,.045,.045,0,2.45,18.0,M.black);
 // Luminarias exteriores
 for(const x of [-21,21]){
  cylinder(environment,.075,8.4,x,4.2,15.3,M.dark,10);
  box(environment,.95,.18,.48,x+.28,8.3,15.3,M.bright);
 }
 for(const [x,z] of [[-21,8],[-22,22],[22,21],[-25,31],[25,29]])tree(x,z,1.45);
 person(9,15.1); person(10.4,14.1,M.concreteDark);
}

buildBuilding();buildGround();
scene.add(new THREE.HemisphereLight(0xe8f7ff,0xa6a19a,1.35));
const sun=new THREE.DirectionalLight(0xfff5de,2.1);sun.position.set(-25,44,38);sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-55,right:55,top:55,bottom:-55,near:1,far:150});
sun.shadow.bias=-.0001;sun.shadow.normalBias=.018;scene.add(sun);

const camera=new THREE.PerspectiveCamera(46,1,.1,250);
const walkCamera=new THREE.PerspectiveCamera(72,1,.06,250);
const lookTarget=new THREE.Vector3(0,10,0);
const view={yaw:0.57,pitch:.33,distance:57,targetYaw:.57,targetPitch:.33,targetDistance:57};
const preset={iso:[.57,.33,57],front:[0,.11,48],side:[1.20,.24,48],top:[.38,1.47,56]};
let walking=false,walkYaw=0,walkPitch=0;
const keys=new Set();
const drag={active:false,lastX:0,lastY:0,startX:0,startY:0,moved:false};
function moveCamera(){
 view.yaw=THREE.MathUtils.lerp(view.yaw,view.targetYaw,.12);
 view.pitch=THREE.MathUtils.lerp(view.pitch,view.targetPitch,.12);
 view.distance=THREE.MathUtils.lerp(view.distance,view.targetDistance,.12);
 const c=Math.cos(view.pitch),s=Math.sin(view.pitch),r=view.distance;
 camera.position.set(lookTarget.x+Math.sin(view.yaw)*r*c,lookTarget.y+s*r,lookTarget.z+Math.cos(view.yaw)*r*c);
 camera.lookAt(lookTarget);
}
function setView(key){
 const arr=preset[key]||preset.iso;
 view.targetYaw=arr[0];view.targetPitch=arr[1];view.targetDistance=arr[2];
 document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===key));
}
function toggleWalk(force){
 walking=typeof force==='boolean'?force:!walking;
 $('#walk').classList.toggle('active',walking);
 $('#walk').innerHTML=walking?'Salir de primera persona <span>×</span>':'Recorrer en primera persona <span>◈</span>';
 $('#help-overlay').classList.toggle('hidden',!walking);
 if(walking){
  walkCamera.position.set(3,1.72,26);
  walkYaw=0;walkPitch=0;
  walkCamera.rotation.set(walkPitch,walkYaw,0,'YXZ');
 }
 keys.clear();
}
function resize(){
 const w=Math.max(1,viewport.clientWidth),h=Math.max(1,viewport.clientHeight);
 renderer.setSize(w,h,false);camera.aspect=walkCamera.aspect=w/h;camera.updateProjectionMatrix();walkCamera.updateProjectionMatrix();
}
const clock=new THREE.Clock();
function animate(){
 const dt=Math.min(clock.getDelta(),.05);
 if(walking){
  const speed=(keys.has('shift')?10.5:5.4)*dt;
  let dx=0,dz=0;
  if(keys.has('w')||keys.has('arrowup'))dz-=1;
  if(keys.has('s')||keys.has('arrowdown'))dz+=1;
  if(keys.has('a')||keys.has('arrowleft'))dx-=1;
  if(keys.has('d')||keys.has('arrowright'))dx+=1;
  if(dx||dz){
   const delta=new THREE.Vector3(dx,0,dz).normalize().multiplyScalar(speed);
   delta.applyAxisAngle(new THREE.Vector3(0,1,0),walkYaw);
   const nx=walkCamera.position.x+delta.x,nz=walkCamera.position.z+delta.z;
   // Visita EXTERIOR: no atravesar el edificio ni otras estructuras.
   const blocked=(x,z)=>x>-16.8&&x<15.15&&z>-7.1&&z<7.4;
   if(!blocked(nx,walkCamera.position.z)&&Math.abs(nx)<68)walkCamera.position.x=nx;
   if(!blocked(walkCamera.position.x,nz)&&Math.abs(nz)<68)walkCamera.position.z=nz;
  }
  walkCamera.rotation.set(walkPitch,walkYaw,0,'YXZ');
  renderer.render(scene,walkCamera);
 }else{moveCamera();renderer.render(scene,camera);}
}

let lastTap=0;
const canvas=renderer.domElement;
canvas.addEventListener('pointerdown',e=>{
 if(e.button!==0)return;
 drag.active=true;drag.moved=false;drag.startX=drag.lastX=e.clientX;drag.startY=drag.lastY=e.clientY;
 try{canvas.setPointerCapture(e.pointerId)}catch{}
});
canvas.addEventListener('pointermove',e=>{
 if(!drag.active)return;
 const dx=e.clientX-drag.lastX,dy=e.clientY-drag.lastY;
 drag.lastX=e.clientX;drag.lastY=e.clientY;
 if(Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY)>3)drag.moved=true;
 if(walking){walkYaw-=dx*.0035;walkPitch=THREE.MathUtils.clamp(walkPitch-dy*.0033,-1.35,1.35);}
 else {view.targetYaw-=dx*.006;view.targetPitch=THREE.MathUtils.clamp(view.targetPitch+dy*.006,-.06,1.53);}
});
canvas.addEventListener('pointerup',()=>{drag.active=false});
canvas.addEventListener('pointercancel',()=>{drag.active=false});
canvas.addEventListener('wheel',e=>{e.preventDefault();if(!walking)view.targetDistance=THREE.MathUtils.clamp(view.targetDistance*(e.deltaY>0?1.09:.91),19,115)},{passive:false});
canvas.addEventListener('contextmenu',e=>e.preventDefault());
canvas.addEventListener('dblclick',()=>{if(!walking)setView('iso')});
window.addEventListener('keydown',e=>{
 const k=e.key.toLowerCase();
 if(walking&&['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright','shift',' '].includes(k)){keys.add(k);e.preventDefault()}
 if(k==='escape'&&walking)toggleWalk(false);
});
window.addEventListener('keyup',e=>{keys.delete(e.key.toLowerCase())});
window.addEventListener('blur',()=>{keys.clear()});
for(const btn of document.querySelectorAll('[data-view]'))btn.addEventListener('click',()=>{if(walking)toggleWalk(false);setView(btn.dataset.view)});
$('#reset').addEventListener('click',()=>{if(walking)toggleWalk(false);setView('iso')});
$('#walk').addEventListener('click',()=>toggleWalk());
for(const [id,obj] of [['show-sign',signage],['show-context',environment],['show-supports',supportGroup],['show-roof',roofGroup]]){
 $('#'+id).addEventListener('change',e=>obj.visible=e.target.checked);
}
for(const [id,mat,key] of [['concrete-color',M.concrete,'concreteColor'],['blue-color',M.blue,'blueColor'],['glass-color',M.glass,'glassColor']]){
 const input=$('#'+id);input.value=readStorage(key,defaults[id==='concrete-color'?'concrete':id==='blue-color'?'blue':'glass']);
 input.addEventListener('input',e=>{mat.color.set(e.target.value);try{localStorage.setItem(key,e.target.value)}catch{}});
}
$('#reset-colors').addEventListener('click',()=>{
 for(const [id,key,mat] of [['concrete-color','concrete',M.concrete],['blue-color','blue',M.blue],['glass-color','glass',M.glass]]){
  const color=defaults[key];$('#'+id).value=color;mat.color.set(color);
  try{localStorage.removeItem(key+'Color')}catch{}
 }
});
window.addEventListener('resize',resize);
if(window.ResizeObserver)new ResizeObserver(resize).observe(viewport);
resize();setView('iso');renderer.setAnimationLoop(animate);
