@echo off
cd /d "%~dp0"
chcp 65001 >nul
TITLE Instalar modelo 3D - SENATI Direccion Nacional
where npm >nul 2>nul
if not errorlevel 1 (
  call npm install
  if errorlevel 1 echo npm no pudo completar la instalacion. Intentaremos descarga directa.
)
if not exist "js\vendor\three.module.js" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\reparar-three.ps1"
)
if not exist "js\vendor\three.module.js" (
 echo ERROR: No se pudo obtener Three.js. Ejecuta REPARAR_THREE.bat mas tarde.
 pause
 exit /b 1
)
echo.
echo LISTO: se encontro js\vendor\three.module.js.
echo Si tienes Laragon abierto, ingresa a http://localhost:8080/Piramide_SENATI_Exterior_3D/
pause
