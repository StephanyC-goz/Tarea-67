@echo off
cd /d "%~dp0"
chcp 65001 >nul
TITLE SENATI Direccion Nacional 3D
if not exist "js\vendor\three.module.js" (
 echo Falta la biblioteca local. Ejecuta INSTALAR.bat primero.
 pause
 exit /b 1
)
start "" "http://localhost:3000"
call npm start
pause
