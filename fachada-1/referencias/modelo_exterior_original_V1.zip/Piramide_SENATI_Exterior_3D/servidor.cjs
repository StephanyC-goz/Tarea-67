const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const root=__dirname;
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.jpg':'image/jpeg','.png':'image/png','.ico':'image/x-icon'};
const port=Number(process.env.PORT||3000);
http.createServer((req,res)=>{
 const parsed=new URL(req.url,'http://localhost');
 let urlPath;
 try{urlPath=decodeURIComponent(parsed.pathname)}catch{res.writeHead(400);res.end('Ruta invalida');return}
 if(urlPath==='/'||urlPath==='')urlPath='/index.html';
 const p=path.resolve(root,'.'+urlPath);
 if(p!==root&&!p.startsWith(root+path.sep)){res.writeHead(403);res.end('Prohibido');return}
 const ext=path.extname(p).toLowerCase();
 if(!mime[ext]){res.writeHead(403);res.end('Tipo de archivo no permitido');return}
 fs.readFile(p,(err,data)=>{
  if(err){res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});res.end('404 No encontrado: '+urlPath);return}
  res.writeHead(200,{'Content-Type':mime[ext], 'Cache-Control':'no-cache'});res.end(data);
 });
}).listen(port,'127.0.0.1',()=>console.log('Abre http://localhost:'+port));
