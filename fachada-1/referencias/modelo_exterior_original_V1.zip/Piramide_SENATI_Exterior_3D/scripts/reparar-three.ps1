$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$target=Join-Path $root 'js\vendor\three.module.js'
$original=Join-Path $root 'node_modules\three\build\three.module.js'
New-Item -ItemType Directory -Force -Path (Split-Path $target -Parent) | Out-Null
if(Test-Path $original){
  Copy-Item -Path $original -Destination $target -Force
  Write-Host 'Three.js copiado desde node_modules.' -ForegroundColor Green
} elseif((Test-Path $target) -and ((Get-Item $target).Length -gt 500000)){
  Write-Host 'La biblioteca local ya existe.' -ForegroundColor Green
} else {
  $links=@(
    'https://raw.githubusercontent.com/mrdoob/three.js/r158/build/three.module.js',
    'https://cdn.jsdelivr.net/npm/three@0.158.0/build/three.module.js',
    'https://unpkg.com/three@0.158.0/build/three.module.js'
  )
  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
  $ok=$false
  foreach($link in $links){
    try{
      Write-Host "Descargando: $link"
      Invoke-WebRequest -Uri $link -OutFile $target -UseBasicParsing -TimeoutSec 40
      if((Get-Item $target).Length -lt 500000){throw 'Archivo incompleto'}
      $ok=$true
      break
    }catch{Write-Warning $_.Exception.Message}
  }
  if(-not $ok){throw 'No pude descargar Three.js. Verifica internet, firewall o proxy y vuelve a intentar.'}
}
if(-not (Test-Path $target)){throw 'No existe three.module.js'}
if((Get-Item $target).Length -lt 500000){throw 'three.module.js esta vacio o incompleto'}
Write-Host "CORRECTO: $target" -ForegroundColor Green
Write-Host 'Ahora inicia el sitio desde Apache Laragon o INICIAR.bat.'
