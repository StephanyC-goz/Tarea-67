const fs = require('node:fs');
const path = require('node:path');
const root=path.resolve(__dirname, '..');
const src=path.join(root,'node_modules','three','build','three.module.js');
const dest=path.join(root,'js','vendor','three.module.js');
if(!fs.existsSync(src)){
 console.error('No se encontro Three.js en node_modules. Ejecuta: npm install');
 process.exit(1);
}
fs.mkdirSync(path.dirname(dest),{recursive:true});
fs.copyFileSync(src,dest);
if(fs.statSync(dest).size<500000){console.error('La copia de Three.js parece incompleta.');process.exit(1);}
console.log('Three.js copiado a js/vendor/three.module.js ('+Math.round(fs.statSync(dest).size/1024)+' KB).');
