@echo off
cd /d "%~dp0"
chcp 65001 >nul
title Reparar Three.js local
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\reparar-three.ps1"
if errorlevel 1 (
 echo.
 echo Fallo la descarga. Comprueba conexion a internet, firewall y prueba nuevamente.
) else (
 echo.
 echo Puedes abrir el modelo 3D.
)
pause
